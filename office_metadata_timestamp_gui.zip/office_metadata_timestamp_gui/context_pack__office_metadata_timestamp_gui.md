# Context Pack: Office Metadata Timestamp GUI

## Goal

Build a Windows-friendly Python/Tkinter GUI for PharmSolu data repair. The user has many files under `D:\PharmSolu` with corrupted filesystem timestamps or corrupted Office "Date last saved" timestamps. The correct reference date is usually the internal Office metadata field "Content created".

The app lets the user paste individual file paths or folder paths, scan metadata, and set filesystem timestamps to the document metadata date.

## Main user scenario

Example input paths:

```text
"D:\PharmSolu\SERVERCS15-GUEST\Kho Nguyen Lieu Bao Bi\Thien\Doc1.docx"
"D:\PharmSolu\SERVERCS15-GUEST\Phong Nghien Cuu Phat Trien\THAO NCPT\GTCN du an san xuat san pham cong nghe 17.05.2016 .doc"
"D:\PharmSolu\bt_loan\Ploan\HD\hdSAGOPHA.doc"
"D:\PharmSolu\bt_loan\Ploan\HD\hd61mangco.doc"
"D:\PharmSolu\SERVERCS15-GUEST\Phong Nghien Cuu Phat Trien\C.Thuy\GIAO VAN THU P.TCKT.doc"
```

The user wants to scan these files/folders and apply the Office "Content created" date to:
- CreationTime
- LastWriteTime / ModifiedTime
- LastAccessTime

## File structure

```text
office_metadata_timestamp_gui.py
run_office_metadata_timestamp_gui.bat
requirements.txt
readme__office_metadata_timestamp_gui.md
context_pack__office_metadata_timestamp_gui.md
```

## Dependencies

Required:
- Python 3.9+
- Tkinter, usually bundled with Python on Windows

Optional:
- olefile

`olefile` is needed for legacy Office compound files:
- .doc
- .xls
- .ppt

Modern OOXML formats are read using only the Python standard library:
- zipfile
- xml.etree.ElementTree

## Important implementation details

### OOXML metadata

Modern Office files store metadata in:

```text
docProps/core.xml
```

Useful XML fields:
- `dcterms:created`
- `dcterms:modified`
- `dc:creator`
- `cp:lastModifiedBy`

### Legacy OLE metadata

Legacy Office files are read with:

```python
import olefile
ole = olefile.OleFileIO(path)
meta = ole.get_metadata()
meta.create_time
meta.last_saved_time
meta.author
meta.last_saved_by
```

### PDF metadata

The app scans raw PDF bytes for:

```text
/CreationDate(D:...)
/ModDate(D:...)
```

### Timestamp setting

On Windows, the app uses `ctypes` and `kernel32.SetFileTime` so it does not require `pywin32`.

The app supports Windows long paths by prepending:

```text
\\?\
```

or:

```text
\\?\UNC\
```

### Safety

The GUI always requires:
1. Scan first.
2. Review table and CSV log.
3. Apply timestamps explicitly.

Default date source:
1. Prefer metadata created / Content created.
2. Do not fallback to modified / Date last saved unless the user enables it.
3. Reject future metadata dates by default.

This protects against files where:
- Content created is valid, e.g. 2016-05-11 12:43
- Date last saved is corrupted, e.g. 2062-05-16 22:57

## Maintenance notes

- Do not make "Date last saved fallback" default ON.
- Keep the code and comments in English.
- Keep the BAT console title explicit.
- Keep the Tk window title explicit.
- Preserve CSV logging for auditability.
- If packaging as ZIP, include README, context pack, and requirements.txt.

## Suggested future prompt

"Update `office_metadata_timestamp_gui.py` to add Microsoft Office COM fallback via pywin32 for legacy .doc files when `olefile` cannot read metadata. Keep it optional and disabled by default. Add timeout protection and CSV logging for COM errors."
