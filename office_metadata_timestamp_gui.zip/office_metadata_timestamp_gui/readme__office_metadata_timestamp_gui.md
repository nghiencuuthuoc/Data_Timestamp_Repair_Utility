# Office Metadata Timestamp GUI

## Purpose

This GUI helps repair wrong Windows file timestamps by reading the internal metadata of Office/PDF documents and setting the filesystem timestamps to the document's real metadata date.

Typical example:

```text
Windows file time: 2062-05-16 22:57
Office metadata / Content created: 2016-05-11 12:43
New Windows file time: 2016-05-11 12:43
```

## Files

```text
office_metadata_timestamp_gui.py
run_office_metadata_timestamp_gui.bat
requirements.txt
readme__office_metadata_timestamp_gui.md
context_pack__office_metadata_timestamp_gui.md
```

## Supported formats

Modern Office files, no external dependency required:

```text
.docx .docm .dotx .dotm
.xlsx .xlsm .xltx .xltm
.pptx .pptm .potx .potm
```

Legacy Office files require `olefile`:

```text
.doc .xls .ppt
```

PDF metadata is scanned directly for:

```text
/CreationDate
/ModDate
```

## How to run

Put these files in the same folder and run:

```bat
run_office_metadata_timestamp_gui.bat
```

The BAT file automatically searches for portable Python 3.12 in the current and parent folders using this pattern:

```bat
Python312\python.exe
..\Python312\python.exe
..\..\Python312\python.exe
```

## Recommended workflow

1. Open the GUI.
2. Paste file/folder paths, one path per line.
3. Keep these options:
   - Scan folders recursively: ON
   - Prefer Content created date: ON
   - Date last saved fallback: OFF
   - Reject future metadata dates: ON
4. Click **Scan metadata**.
5. Review the table and CSV log.
6. Click **Apply timestamps** only after verifying the target dates.

## Important note

For files like the screenshot where `Content created = 2016-05-11 12:43` but `Date last saved = 2062-05-16 22:57`, keep **Date last saved fallback** turned OFF. This ensures the app uses the true `Content created` date and avoids the corrupted future date.
