# Context Pack: Office Metadata Timestamp GUI v2

## Project goal

Create a robust Windows GUI for PharmSolu timestamp repair. The user pastes files or folders, scans document metadata, reviews target dates, and applies file timestamps.

## Real issue from screenshot

The previous GUI showed:

```text
Doc1.docx -> error -> [Errno 22] Invalid argument
hdSAGOPHA.doc -> no_valid_date even though metadata_created = 2023-08-09 09:50:00
```

## Root cause analysis

### `[Errno 22] Invalid argument`

On Windows, `datetime.fromtimestamp()` can raise `[Errno 22] Invalid argument` when the file's filesystem timestamp is corrupted or outside the supported datetime range. The previous app called `get_fs_times()` before metadata scanning, so one bad filesystem timestamp could stop the whole file from being scanned.

v2 fix:

```python
safe_fromtimestamp()
get_fs_times_safe()
```

Invalid filesystem times are stored as diagnostic text in `fs_times.error`; metadata scanning still continues.

### Legacy `.doc` no_valid_date

Legacy Office `.doc` metadata is read with `olefile`. v2 normalizes OLE `create_time` and `last_saved_time` safely, validates candidates with detailed rejection notes, and selects `metadata_created_content_created` when valid.

## File structure

```text
office_metadata_timestamp_gui_v2.py
run_office_metadata_timestamp_gui_v2.bat
requirements.txt
readme__office_metadata_timestamp_gui_v2.md
context_pack__office_metadata_timestamp_gui_v2.md
```

## Dependencies

Required:
- Python 3.9+
- Tkinter

Optional:
- olefile>=0.47 for `.doc`, `.xls`, `.ppt`

## Timestamp sources and priority

Default priority:

1. Office/PDF metadata created date: `Content created`, OOXML `dcterms:created`, OLE `create_time`, PDF `/CreationDate`.
2. Optional `Date last saved` fallback only when enabled.
3. Optional filename/path date fallback, e.g. `17.05.2016`.

## Safety defaults

- `Allow Date last saved fallback` defaults OFF.
- `Reject future metadata dates` defaults ON.
- Scan and CSV log are created before apply.
- Apply requires confirmation.

## Windows timestamp setting

Uses `ctypes` and `kernel32.SetFileTime` without requiring `pywin32`. Supports long paths with `\\?\` and `\\?\UNC\` conversion.

## Suggested future improvements

1. Add optional Microsoft Office COM fallback for difficult legacy `.doc` files when `olefile` fails.
2. Add row selection so only selected rows are applied.
3. Add a repair mode that uses filename/path dates first for archive folders where metadata is missing.
4. Add command-line batch mode using the same metadata logic.
