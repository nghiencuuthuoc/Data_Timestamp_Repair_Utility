# Office Metadata Timestamp GUI v2

## Purpose

This GUI repairs wrong Windows file timestamps by reading the internal metadata of Office/PDF documents and setting the filesystem timestamps to the document's real metadata date.

Typical case:

```text
Windows filesystem date is wrong or unreadable.
Office Properties > Details > Content created = 2016-05-11 12:43
New Windows file timestamp = 2016-05-11 12:43
```

## What v2 fixes

v2 fixes the two issues shown in the user's screenshot:

1. `[Errno 22] Invalid argument` on a `.docx` file.
   - Cause: Windows file timestamps can be corrupted enough that Python cannot convert them with `datetime.fromtimestamp()`.
   - Fix: filesystem time conversion is now safe; if one filesystem timestamp is invalid, the program still reads Office metadata and can still repair the file.

2. Legacy `.doc` metadata was found but the row still showed `no_valid_date`.
   - Cause: the previous decision/rejection path was not clear enough for OLE dates and bad filesystem values.
   - Fix: v2 normalizes OLE datetimes, shows a full decision note, and selects `Content created` when it is valid.

## Supported files

Modern Office files, no external dependency required:

```text
.docx .docm .dotx .dotm
.xlsx .xlsm .xltx .xltm
.pptx .pptm .potx .potm
```

Legacy Office files require `olefile`:

```text
.doc .xls .ppt
```

PDF support:

```text
/CreationDate
/ModDate
```

Filename/path fallback is also supported for names like:

```text
GTCN du an san xuat san pham cong nghe 17.05.2016 .doc
```

## How to run

Put these files in the same folder and run:

```bat
run_office_metadata_timestamp_gui_v2.bat
```

The BAT file finds portable Python 3.12 from the current folder or parent folders using the user's preferred pattern.

## Recommended options for PharmSolu repair

Keep these settings:

```text
Scan folders recursively: ON
Only supported extensions: ON
Prefer Content created date: ON
Use filename/path date fallback: ON
Allow Date last saved fallback: OFF
Reject future metadata dates: ON
CreationTime: ON
ModifiedTime / LastWriteTime: ON
AccessedTime: ON
```

Why keep `Allow Date last saved fallback` OFF? Some files have corrupted `Date last saved` values such as year 2062. The safer field is usually `Content created`.

## CSV logs

The GUI automatically saves scan/apply logs in:

```text
office_timestamp_logs
```

The log includes metadata date, filesystem date, selected target date, target source, and any timestamp conversion error.
