# Office Metadata Timestamp GUI v3

## Purpose

This GUI repairs wrong Windows file timestamps by reading the internal metadata of Office/PDF documents and setting filesystem timestamps to the document's real date.

## New in v3

v3 adds a filter for the user's requested workflow:

```text
Scan only files with filesystem date > current date
```

This means clean files are skipped before metadata reading. It is faster and safer when scanning a large folder such as:

```text
D:\PharmSolu
```

## Recommended settings

For PharmSolu corrupted future-date repair:

```text
Scan folders recursively: ON
Only supported extensions: ON
Scan only files with filesystem date > current date: ON
Compare by date only, not exact time: ON
Show skipped non-future files: OFF
Prefer Content created date: ON
Allow Date last saved fallback: OFF
Reject future metadata dates: ON
Use filename/path date fallback: ON
CreationTime: ON
ModifiedTime / LastWriteTime: ON
AccessedTime: ON
```

## Why keep Date last saved fallback OFF?

Some files have a valid Office property:

```text
Content created: 2016-05-11 12:43
```

but a corrupted value:

```text
Date last saved: 2062-05-16 22:57
```

So v3 should use `Content created` first and should not use `Date last saved` unless you deliberately enable it.

## Supported file types

Modern Office files:

```text
.docx .docm .dotx .dotm
.xlsx .xlsm .xltx .xltm
.pptx .pptm .potx .potm
```

Legacy Office files, requires `olefile`:

```text
.doc .xls .ppt
```

PDF metadata:

```text
/CreationDate
/ModDate
```

Filename/path date fallback supports examples such as:

```text
17.05.2016
17-05-2016
2016-05-17
```

## How to run

Put these files in the same folder and run:

```bat
run_office_metadata_timestamp_gui_v3.bat
```

The BAT file searches for portable Python 3.12 in the current and parent folders.

## Logs

CSV logs are saved to:

```text
office_timestamp_logs_v3
```

The log includes:

```text
future_fs_fields
fs_time_error
metadata_created
metadata_modified
target_time
applied
```
