# Context Pack: Office Metadata Timestamp GUI v3

## Goal

Create a Windows-friendly Tkinter GUI to repair future-dated files in `D:\PharmSolu`.

The user wants v3 to scan only files whose filesystem timestamp is greater than the current local date. The app should skip normal files before reading Office/PDF metadata.

## Main v3 feature

New option:

```text
Scan only files with filesystem date > current date
```

Implementation:

- Read raw filesystem timestamps from `Path.stat()`.
- On Windows, `st_ctime` is CreationTime.
- Compare raw timestamps numerically against a future threshold.
- Do this before metadata reading.
- If no filesystem field is future, skip the file.
- This avoids expensive metadata reading for normal files.

## Future threshold logic

The GUI includes:

```text
Compare by date only, not exact time
```

Default: ON.

When ON:
- future means file date is after today.
- threshold is tomorrow at local 00:00.

When OFF:
- future means file timestamp is later than current local time.

## Supported metadata sources

### OOXML

Use standard library:

```python
zipfile.ZipFile(path).read("docProps/core.xml")
```

Parse:
- `created`
- `modified`
- `creator`
- `lastModifiedBy`

### Legacy OLE

Use optional dependency:

```python
olefile
```

Fields:
- `meta.create_time`
- `meta.last_saved_time`
- `meta.author`
- `meta.last_saved_by`

### PDF

Scan first and last 1MB of bytes for:

```text
/CreationDate(...)
/ModDate(...)
```

### Filename/path fallback

Support dates such as:

```text
17.05.2016
17-05-2016
2016-05-17
```

## Safety defaults

Recommended default options:

```text
Scan only future files: ON
Compare by date only: ON
Show skipped non-future files: OFF
Prefer Content created date: ON
Allow Date last saved fallback: OFF
Reject future metadata dates: ON
Use filename/path date fallback: ON
Set CreationTime: ON
Set ModifiedTime: ON
Set AccessedTime: ON
```

## Timestamp writing

On Windows, use `ctypes` with:

```text
kernel32.CreateFileW
kernel32.SetFileTime
```

Long paths use:

```text
\\?\
\\?\UNC\
```

No `pywin32` dependency is required.

## ZIP requirements

This package contains Python files, so include:

```text
requirements.txt
readme__office_metadata_timestamp_gui_v3.md
context_pack__office_metadata_timestamp_gui_v3.md
```

## Maintenance notes

- Keep BAT and Python comments/messages in English.
- Keep the BAT window title explicit: `Office_Metadata_Timestamp_GUI_v3`.
- Do not make `Date last saved fallback` default ON.
- Do not display skipped files by default; folders may contain thousands of normal files.
- Always write CSV logs after scan/apply.
